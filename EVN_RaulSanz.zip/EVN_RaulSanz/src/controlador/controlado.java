package controlador;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import modelo.Articulo;

public class controlado {

	public boolean comprobarFichero() {
		File f= new File("src/inventario.xml");
		if (f.exists()) {
			return true;
		}else {
			return false;
		}
	}
	
	public Articulo devolverArticulo(String codigo) throws ParserConfigurationException, SAXException, IOException, TransformerFactoryConfigurationError, TransformerException {
		
		
		DocumentBuilderFactory dbf= DocumentBuilderFactory.newInstance();
		DocumentBuilder builder= dbf.newDocumentBuilder();
		Document registroArticulos=builder.parse(new File("src/inventario.xml"));
		
		registroArticulos.getDocumentElement().normalize();
		
		NodeList articulos=registroArticulos.getElementsByTagName("articulo");
		
		for (int i = 0; i < articulos.getLength(); i++) {
			Node articulo=articulos.item(i);
			if (articulo.getNodeType()==Node.ELEMENT_NODE) {
				Element art=(Element) articulo;
				String codi=art.getElementsByTagName("codigo").item(0).getTextContent();
				if (codi.equals(codigo)) {
					
					String desc=art.getElementsByTagName("descripcion").item(0).getTextContent();
					int unidades=Integer.parseInt(art.getElementsByTagName("unidades").item(0).getTextContent());
					Double precio=Double.parseDouble(art.getElementsByTagName("precio").item(0).getTextContent());
					if (unidades>1) {
						art.getElementsByTagName("unidades").item(0).setTextContent(String.valueOf(unidades-1));
						Source origen=new DOMSource(registroArticulos);
						Result resultado=new StreamResult(new File("src/inventario.xml"));
						Transformer transformador=TransformerFactory.newInstance().newTransformer();
						transformador.transform(origen, resultado);
					}
					else {
						art.getParentNode().removeChild(art);
						Source origen=new DOMSource(registroArticulos);
						Result resultado=new StreamResult(new File("src/inventario.xml"));
						Transformer transformador=TransformerFactory.newInstance().newTransformer();
						transformador.transform(origen, resultado);
						
						try {
							BufferedWriter bf= new BufferedWriter(new FileWriter("C:\\Users\\34653\\eclipse-workspace\\EXAMEN1EVNORMAL_RaulSanz\\src\\cambios.txt",true));
							bf.write(codi+" "+precio+" "+LocalDate.now());
							bf.newLine();
							bf.close();
						} catch (IOException e) {
							// TODO: handle exception
							e.printStackTrace();
						}
					}
					
					Articulo a = new Articulo(codi, desc, unidades, precio);
					
					
					return a;
				}
			}
		}
		return null;
	}
	
	
}
