package vista;

import java.io.IOException;
import java.util.Scanner;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;

import org.xml.sax.SAXException;

import controlador.controlado;
import modelo.Articulo;

public class Principal {

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, TransformerFactoryConfigurationError, TransformerException {
		// TODO Auto-generated method stub

		controlado c  = new controlado();
		Scanner sc= new Scanner(System.in);
		
		String ch=" ";
		if (c.comprobarFichero()) {
			
			
			while (ch.length()>0) {
				System.out.println("Dime un codigo");
				String codigo=sc.nextLine();
				Articulo a = c.devolverArticulo(codigo);
				if (a==null) {
					System.out.println("NO EXISTE ESE CODIGO");
					break;
				}
				else {
					System.out.println(a);
				}
			}
		}else {
			System.out.println("EL FICHERO NO EXISTE");
		}
		
	}

}
