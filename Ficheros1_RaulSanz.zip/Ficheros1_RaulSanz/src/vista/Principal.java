package vista;

import java.io.IOException;
import java.util.Scanner;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;

import org.xml.sax.SAXException;

import controlador.Controlador;
import modelo.Articulo;

public class Principal {

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, TransformerFactoryConfigurationError, TransformerException {
		// TODO Auto-generated method stub
		
		Scanner sc= new Scanner(System.in);
		Controlador c= new Controlador();
		
		String ch=" ";
		if (c.comprobarFichero()) {
			while(ch.length()>0) {
				System.out.println("Dime un codigo de articulo");
				ch=sc.nextLine();
				Articulo a = c.devolverCodigo2(ch);
				
				if (a==null) {
					System.out.println("NO EXISTE ESE ARTICULO");
					System.out.println("----------------------");
					c.precioTotal();
				}
				else {
					System.out.println(a);
					
				}
			}
		}
		
	}

}
