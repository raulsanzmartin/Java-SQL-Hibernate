package controlador;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import modelo.Articulo;

public class Controlador {

	
	public boolean comprobarFichero() {
		
		File f = new File("src/inventario.xml");
		if (f.exists()) {
			return true;
		}
		else {
			return false;
		}
	}
	
	
	
	
	
	public Articulo devolverCodigo2(String codigo) throws ParserConfigurationException, SAXException, IOException, TransformerException {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = dbf.newDocumentBuilder();
        Document registroArticulos = builder.parse(new File("src/inventario.xml"));

        registroArticulos.getDocumentElement().normalize();

        NodeList articulos = registroArticulos.getElementsByTagName("articulo");

        for (int i = 0; i < articulos.getLength(); i++) {
            Node arti = articulos.item(i);
            if (arti.getNodeType() == Node.ELEMENT_NODE) {
                Element a = (Element) arti;
                if (a.getElementsByTagName("codigo").item(0).getTextContent().equals(codigo)) {
                    String cod = a.getElementsByTagName("codigo").item(0).getTextContent();
                    String desc = a.getElementsByTagName("descripcion").item(0).getTextContent();
                    int unidades = Integer.parseInt(a.getElementsByTagName("unidades").item(0).getTextContent());
                    Double precio = Double.parseDouble(a.getElementsByTagName("precio").item(0).getTextContent());

                    if (unidades > 1) {
                        a.getElementsByTagName("unidades").item(0).setTextContent(String.valueOf(unidades - 1));
                    } else {
                        a.getParentNode().removeChild(a);
                        System.out.println("ARTICULO ELIMINADO");
                    }

                    
                    Transformer transformer = TransformerFactory.newInstance().newTransformer();
                    DOMSource source = new DOMSource(registroArticulos);
                    StreamResult result = new StreamResult(new File("src/inventario.xml"));
                    transformer.transform(source, result);

                    
                    
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                    String fechaHora = LocalDateTime.now().format(formatter);
                    try (BufferedWriter writer = new BufferedWriter(new FileWriter("src/modificaciones.txt", true))) {
                        writer.write(fechaHora +"," + cod + "," + precio);
                        writer.newLine();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    Articulo art = new Articulo(cod, desc, unidades, precio);
                    return art;
                }
            }
        }
        return null;
    }
	public void precioTotal() {
		
		try {
			BufferedReader br=new BufferedReader(new FileReader("src/modificaciones.txt"));
			String linea="";
			Double precioTo=0.0;
			
			while ((linea=br.readLine())!=null) {
				
				String partes[]=linea.split(",");
				precioTo=precioTo+(Double.parseDouble(partes[2]));
				
						
			}
			System.out.println("PRECIO TOTAL: "+precioTo );
			br.close();
		} catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
}
