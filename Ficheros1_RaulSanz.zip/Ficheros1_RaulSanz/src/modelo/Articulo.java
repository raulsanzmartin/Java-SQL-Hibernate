package modelo;
public class Articulo {
	
	private String codigo;
	private String descripcion;
	private int unidades;
	private double precio;
	
	public Articulo(String codigo, String descripcion, int unidades, double precio) {
		super();
		this.codigo = codigo;
		this.descripcion = descripcion;
		this.unidades = unidades;
		this.precio = precio;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public int getUnidades() {
		return unidades;
	}

	public void setUnidades(int unidades) {
		this.unidades = unidades;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return "Articulo [codigo=" + codigo + ", descripcion=" + descripcion + ", unidades=" + unidades + ", precio="
				+ precio + "]";
	}
	
}
