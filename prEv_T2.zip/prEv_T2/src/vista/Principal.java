package vista;

import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.Scanner;

import controlador.libroControlador;
import controlador.prestamoControlador;

public class Principal {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		
		Scanner sc= new Scanner(System.in);
		libroControlador lc=new libroControlador();
		prestamoControlador pc=new prestamoControlador();
		int op=0;
		while (op!=5) {
			System.out.println("1.Dar de alta un libro");
			System.out.println("2.Prestar libro");
			System.out.println("3.Mostrar Inventario");
			System.out.println("4.Devolver un libro");
			op=sc.nextInt();
			switch (op) {
			case 1: {
				System.out.println("Dime el isbn del libro");
				sc.nextLine();
				String isbn=sc.nextLine();
				System.out.println("Dime el titulo del libro");
				String tituloString=sc.nextLine();
				System.out.println("Dime el autor del libro");
				String auto=sc.nextLine();
				try {
				lc.insertarLibro(isbn, tituloString, auto);
				}catch(SQLIntegrityConstraintViolationException e) {
					System.out.println("Ese libro ya esta insertado");
				}
				break;
			}
			case 2:{
				
				System.out.println("has elegido hacer un prestamo.ESTOS SON LOS LIBROS DISPONIBLES");
				System.out.println(pc.listarNoPrestados());
				System.out.println("Dime el isbn del libro que quieres prestar");
				sc.nextLine();
				String isbn=sc.nextLine();
				pc.hacerPrestamos(isbn);
				
				break;
			}
			case 3:{
				
				System.out.println("Has elegido mostrar el inventario");
				System.out.println( lc.mostrarInventario()); 
			}
			
			case 4:{
				System.out.println("Has decidido devolver un libro");
				System.out.println("Dime el isbn del libro que vas a devolver");
				sc.nextLine();
				String isbn=sc.nextLine();
				pc.devolverPrestamo(isbn);
				
			}
			}
		}
	}

}
