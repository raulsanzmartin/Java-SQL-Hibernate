package modelo;

import java.sql.Date;

public class Prestamos {
	int id;
	String isbn;
	Date fecha_venta;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public Date getFecha_venta() {
		return fecha_venta;
	}
	public void setFecha_venta(Date fecha_venta) {
		this.fecha_venta = fecha_venta;
	}
	@Override
	public String toString() {
		return "Prestamos [id=" + id + ", isbn=" + isbn + ", fecha_venta=" + fecha_venta + "]";
	}
	
}
