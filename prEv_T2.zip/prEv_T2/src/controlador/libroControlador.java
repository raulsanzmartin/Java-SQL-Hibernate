package controlador;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import modelo.Libro;

public class libroControlador {
	private Connection c;
	public libroControlador() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		c=DriverManager.getConnection("jdbc:mysql://localhost/ad_biblio","root","");
	}
	
	public void insertarLibro(String isbn,String titulo,String autor) throws SQLException {
		String insert="insert into libro values(?,?,?,?)";
		PreparedStatement s=c.prepareStatement(insert);
		s.setString(1, isbn);
		s.setString(2, titulo);
		s.setString(3, autor);
		s.setBoolean(4, false);
		s.executeUpdate();
		
		
	}
	
	public List<Libro> mostrarInventario() throws SQLException{
		List<Libro> l = new ArrayList<>();
		Libro li= new Libro();
		
		Statement s= c.createStatement();
		String sql="Select * from libro";
		ResultSet r=s.executeQuery(sql);
		
		while(r.next()) {
			
			String isbn=r.getString("isbn");
			String titulo=r.getString("titulo");
			String autor=r.getString("autor");
			Boolean prestado=r.getBoolean("prestado");
			
			li.setAutor(autor);
			li.setIsbn(isbn);
			li.setTitulo(titulo);
			li.setPrestado(prestado);
			
			l.add(li);
			return l;
					
					
		}
		return l;
		
		
		
	}
}
