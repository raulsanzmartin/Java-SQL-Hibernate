package controlador;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import modelo.Libro;

public class prestamoControlador {
	
	
		private Connection c;
		public prestamoControlador() throws ClassNotFoundException, SQLException {
			Class.forName("com.mysql.cj.jdbc.Driver");
			c=DriverManager.getConnection("jdbc:mysql://localhost/ad_biblio","root","");
		}
		
		
		public List<Libro> listarNoPrestados() throws SQLException {
			List<Libro> l=new ArrayList<>();
			Libro li= new Libro();
			String sql="Select * from libro where prestado=0";
			Statement sen=c.createStatement();
			ResultSet r=sen.executeQuery(sql);
			
			while (r.next()) {
				String isbn=r.getString("isbn");
				String titulo=r.getString("titulo");
				String autor=r.getString("autor");
				
				li.setAutor(autor);
				li.setIsbn(isbn);
				li.setTitulo(titulo);
				
				l.add(li);
				return l;
				
			}
			return l;
			
		}
		
		public void hacerPrestamos(String isbn) throws SQLException {
			
			Date fecha=Date.valueOf(LocalDate.now());
			
			String comp="select * from libro where isbn=? and prestado=0";
			PreparedStatement sen=c.prepareStatement(comp);
			sen.setString(1, isbn);
			ResultSet r=sen.executeQuery();
			
			if(r.next()) {
				
				String sql="insert into prestamos values (?,?,?)";
				PreparedStatement s=c.prepareStatement(sql);
				s.setInt(1, 0);
				s.setString(2, isbn);
				s.setDate(3, fecha);
				
				s.executeUpdate();
				
				String actua="UPDATE libro SET prestado= 1 WHERE isbn=? ";
				PreparedStatement sentencia=c.prepareStatement(actua);
				sentencia.setString(1, isbn);
				sentencia.executeUpdate();
				
				
			}
			
		}
		public void devolverPrestamo(String isbn) throws SQLException {
			
			String sql1="Select * from prestamos where isbn=?";
			PreparedStatement s=c.prepareStatement(sql1);
			s.setString(1, isbn);
			
			ResultSet r= s.executeQuery();
			if(r.next()) {
				String sql2="delete from prestamos where isbn=?";
				PreparedStatement s2=c.prepareStatement(sql2);
				s2.setString(1, isbn);
				s2.executeUpdate();
				
				String sql3="update libro set prestado=0 where isbn=?";
				PreparedStatement s3=c.prepareStatement(sql3);
				s3.setString(1, isbn);
				s3.executeUpdate();
			}
			else {
				System.out.println("Ese libro no esta prestado");
			}
		}
}
