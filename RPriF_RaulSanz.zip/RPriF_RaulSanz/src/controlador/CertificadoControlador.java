package controlador;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;



public class CertificadoControlador {
	private Connection c;
	public CertificadoControlador() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		c=DriverManager.getConnection("jdbc:mysql://localhost/ad_recu_hibernate","root","");
	
	}
	/*MIRARRR CODIGOOO*/
	
	public void certificadosFechas(Date fecha1, Date fecha2) throws SQLException, IOException {
	    String sql = "SELECT * FROM certificado WHERE fecha_examen BETWEEN ? AND ?";
	    PreparedStatement stmt = c.prepareStatement(sql);
	    stmt.setDate(1, fecha1);
	    stmt.setDate(2, fecha2);

	    ResultSet rs = stmt.executeQuery();

	    File file = new File("src/certificados.txt");
	   
	    try (BufferedWriter bw = new BufferedWriter(new FileWriter(file))) {
	        while (rs.next()) {
	            String codigo = rs.getString("cod_examen");
	            String descripcion = rs.getString("descripcion");
	            double precio = rs.getDouble("precio");
	            Date fecha=rs.getDate("fecha_examen");

	            bw.write(codigo + " " + descripcion + " " + precio+" "+fecha);
	            bw.newLine(); 
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    } finally {
	       
	        if (stmt != null) stmt.close();
	        if (rs != null) rs.close();
	    }
	}
	
	
	public void crearXML() throws SQLException, ParserConfigurationException, TransformerFactoryConfigurationError, TransformerException {
		Statement sentencia=c.createStatement();
		String sql="Select * from certificado";
		ResultSet res1=sentencia.executeQuery(sql);
		
		DocumentBuilderFactory dbf=DocumentBuilderFactory.newInstance();
		DocumentBuilder builder=dbf.newDocumentBuilder();
		
		DOMImplementation implementacion=builder.getDOMImplementation();
		Document registroCertificados=implementacion.createDocument(null, "inscripciones", null);
		registroCertificados.setXmlVersion("1.0");
		while (res1.next()) {
			String cod_examen=res1.getString("cod_examen");
			String descripcion=res1.getString("descripcion");
			Date fecha_examen=res1.getDate("fecha_examen");
			Double precio=res1.getDouble("precio");
			
			String fecha=fecha_examen.toString();
			String preciobien=precio.toString();
			
			
			
			Element certificado=registroCertificados.createElement("certificado");
			registroCertificados.getDocumentElement().appendChild(certificado);
			
			Element cod_examen2=registroCertificados.createElement("cod_examen");
			Text textocod=registroCertificados.createTextNode(cod_examen);
			cod_examen2.appendChild(textocod);
			certificado.appendChild(cod_examen2);
			
			
			Element descripcion2=registroCertificados.createElement("descripcion");
			Text textodesc=registroCertificados.createTextNode(descripcion);
			descripcion2.appendChild(textodesc);
			certificado.appendChild(descripcion2);
			
			Element fechaexamen2=registroCertificados.createElement("fecha_examen");
			Text textofech=registroCertificados.createTextNode(fecha);
			fechaexamen2.appendChild(textofech);
			certificado.appendChild(fechaexamen2);
			
			Element precio2=registroCertificados.createElement("precio");
			Text textopre=registroCertificados.createTextNode(preciobien);
			precio2.appendChild(textopre);
			certificado.appendChild(precio2);
			
			Source origen=new DOMSource(registroCertificados);
			Result resultado=new StreamResult(new File("certificadosxml.xml"));
			Transformer transformador=TransformerFactory.newInstance().newTransformer();
			transformador.transform(origen, resultado);
			
			
			
			
			
			
			
		}
		
	}

}
