package controlador;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class ControladorInscripcion {
	
	private Connection c;
	public ControladorInscripcion() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		c=DriverManager.getConnection("jdbc:mysql://localhost/ad_recu_hibernate","root","");
	
	}
	
	public void insertarInscripcion(String dni,String certificado) throws SQLException {
		
		String certi="";
		
		String sql="Select * from certificado where descripcion=?";
		PreparedStatement sentencia=c.prepareStatement(sql);
		sentencia.setString(1, certificado);
		
		ResultSet resultado=sentencia.executeQuery();
		while (resultado.next()) {
			 certi=resultado.getString("cod_examen");
			
		}
		
		String insert="insert into inscripcion values(?,?,?)";
		PreparedStatement sen=c.prepareStatement(insert);
		sen.setString(1, dni);
		sen.setString(2, certi);
		sen.setString(3, "pendiente");
		sen.executeUpdate();
		
		sentencia.close();
		sen.close();
		resultado.close();
		
		
	}
	
	
	public void precioPorPagar(String dni) throws SQLException {
		
		Double total=0.0;
		
		String sql="Select * from inscripcion where dni=? and pagado=?";
		PreparedStatement sen1=c.prepareStatement(sql);
		sen1.setString(1, dni);
		sen1.setString(2, "pendiente");
		ResultSet resultado=sen1.executeQuery();
		
		while(resultado.next()) {
			
			String certificado=resultado.getString("cod_examen");
			
			String sql2="Select * from certificado where cod_examen=?";
			PreparedStatement sen2=c.prepareStatement(sql2);
			sen2.setString(1, certificado);
			ResultSet resultado2=sen2.executeQuery();
			while (resultado2.next()) {
				
				Double precio=resultado2.getDouble("precio");
				total=total+precio;
			}
			
		}
		System.out.println("TOTAL PENDIENTE DE PAGO:"+total+" €");
	}
	
	
	public void cambiarPagado(String dni, String certificado) throws SQLException {
		
		String sql="Select * from inscripcion where dni=? and cod_examen=? ";
		PreparedStatement sen1=c.prepareStatement(sql);
		sen1.setString(1, dni);
		sen1.setString(2, certificado);
		ResultSet resul1=sen1.executeQuery();
		while(resul1.next()) {
			String pagado=resul1.getString("pagado");
			
			if (pagado.equals("pagado")) {
				System.out.println("ESE CERTIFICADO YA ESTA PAGADO");
			}
			else {
				String sql2="Update inscripcion set pagado=? where dni=? and cod_examen=?";
				PreparedStatement sen2=c.prepareStatement(sql2);
				sen2.setString(1,"pagado");
				sen2.setString(2,dni);
				sen2.setString(3, certificado);
				sen2.executeUpdate();
			}
		}
	}
	
	public void eliminarInscripcion(String codigo,String dni) throws SQLException {
		Date hoy=Date.valueOf(LocalDate.now());
		String sql1="Select * from certificado where cod_examen=? and fecha_examen<?";
		PreparedStatement sen1=c.prepareStatement(sql1);
		sen1.setString(1, codigo);
		sen1.setDate(2, hoy);
		ResultSet res1=sen1.executeQuery();
		if (res1.next()) {
			System.out.println("ESTA CADUCADO");
		}
		else {
			String sql2="Delete from inscripcion where dni=? and cod_examen=? and pagado=?";
			PreparedStatement sen2=c.prepareStatement(sql2);
			sen2.setString(1, dni);
			sen2.setString(2,codigo);
			sen2.setString(3, "pendiente");
			int valor=sen2.executeUpdate();
			if (valor==1) {
				System.out.println("SE HA ELIMINADO LA INSCRIPCION");
			}
			else {
				System.out.println("NO SE HA ELIMINADO LA INSCRIPCION");
			}
			
		}
	}
}
