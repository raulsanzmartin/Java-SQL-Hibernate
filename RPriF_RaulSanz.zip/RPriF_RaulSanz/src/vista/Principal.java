package vista;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.Scanner;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;

import controlador.CertificadoControlador;
import controlador.ControladorInscripcion;

public class Principal {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		Scanner sc= new Scanner(System.in);
		ControladorInscripcion ci=new ControladorInscripcion();
		CertificadoControlador cc= new CertificadoControlador();
		int op=0;
		
		
		while(op!=7) {
			System.out.println("1.Realizar una inscripcion");
			System.out.println("2.Mostrar precio pendiente por pagar");
			System.out.println("3.Modificar a pagado un certificado");
			System.out.println("4.Mostrar todos los certificados que se realizaran entre 2 fechas");
			System.out.println("5.Eliminar una inscripcion");
			System.out.println("6.Copiar informacion de inscripciones de un usuario a XML");
			System.out.println("7.SALIR");
			op=sc.nextInt();
			switch (op) {
			case 1: {
				System.out.println("Vas a realizar una inscripcion(Se quedara pendiente de pago hasta que hagas el pago)");
				System.out.println("Dime tu DNI");
				sc.nextLine();
				String dni=sc.nextLine();
				System.out.println("Dime el certificado que quieres");
				String certificado=sc.nextLine();
				
				ci.insertarInscripcion(dni, certificado);
				break;
			}
			case 2:{
				System.out.println("Dime tu dni y te dire el precio que te queda por pagar");
				sc.nextLine();
				String dni=sc.nextLine();
				ci.precioPorPagar(dni);
				break;
			}
			case 3:{
				System.out.println("Dime tu dni");
				sc.nextLine();
				String dni=sc.nextLine();
				System.out.println("Dime el codigo del examen que quieras pagar");
				String codigo=sc.nextLine();
				ci.cambiarPagado(dni, codigo);
				break;
			}
			case 4:{
				System.out.println("Dime la primera fecha (yyyy-mm-dd)");
				sc.nextLine();
				String fe=sc.nextLine();
				System.out.println("Dime la segunda fecha (yyyy-mm-dd)");
				String f2=sc.nextLine();
				
				Date fecha1=Date.valueOf(fe);
				Date fecha2=Date.valueOf(f2);
				
				
				try {
					cc.certificadosFechas(fecha1, fecha2);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				break;
				
			}
			case 5:{
				System.out.println("Dime el dni");
				sc.nextLine();
				String dni=sc.nextLine();
				System.out.println("Dime el codigo del certificado");
				String codigo=sc.nextLine();
				ci.eliminarInscripcion(codigo, dni);
			
				break;
			}
			case 6:{
				try {
					cc.crearXML();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParserConfigurationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (TransformerFactoryConfigurationError e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (TransformerException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}
			case 7:{
				System.out.println("SALIENDO...");
				break;
			}
			default:
				System.out.println("OPCION INCORRECTA");
			}
			
		}
		
	}

}
