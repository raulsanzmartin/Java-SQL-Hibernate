package modelo;

import java.util.Date;

public class Certificado {

	String cod_examen;
	String descripcion;
	Date fecha_examen;
	Double precio;
	public String getCod_examen() {
		return cod_examen;
	}
	public void setCod_examen(String cod_examen) {
		this.cod_examen = cod_examen;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public Date getFecha_examen() {
		return fecha_examen;
	}
	public void setFecha_examen(Date fecha_examen) {
		this.fecha_examen = fecha_examen;
	}
	public Double getPrecio() {
		return precio;
	}
	public void setPrecio(Double precio) {
		this.precio = precio;
	}
	@Override
	public String toString() {
		return "Certificado [cod_examen=" + cod_examen + ", descripcion=" + descripcion + ", fecha_examen="
				+ fecha_examen + ", precio=" + precio + "]";
	}
	
}
