package vista;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.Scanner;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;

import controladores.InscripcionControlador;

public class Principal {

	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
		// TODO Auto-generated method stub

		
		Scanner sc= new Scanner(System.in);
		InscripcionControlador ic= new InscripcionControlador();
		int op=0;
		
		while (op!=7) {
			System.out.println("1.Realizar inscripcon a certificado");
			System.out.println("2.Mostrar el precio pendiente");
			System.out.println("3.Modificar a pagado un certificado");
			System.out.println("4.Mostrar certificados entre 2 fecha");
			System.out.println("5.Eliminar inscripcion");
			System.out.println("6.Copia XML");
			System.out.println("7.SALIR");
			op=sc.nextInt();
			switch (op) {
			case 1: {
				System.out.println("Dime tu dni");
				sc.nextLine();
				String dni=sc.nextLine();
				System.out.println("Dime el certificado que quieres");
				String certi=sc.nextLine();
				
				ic.insertarInscripcion(dni, certi);
				
				break;
			}
			case 2:{
				
				System.out.println("Dime tu dni");
				sc.nextLine();
				String dni=sc.nextLine();
				System.out.println("PRECIO PENDIENTE: "+ic.precioPendiente(dni));
				break;
			}
			case 3:{
				System.out.println("Dime tu dni");
				sc.nextLine();
				String dni=sc.nextLine();
				System.out.println("Dime el certificado que quieres pagar");
				String codigo=sc.nextLine();
				ic.cambiarAPagado(dni, codigo);
				break;
			}
			case 4:{
				System.out.println("Dime la primera fecha (yyyy-mm-dd)");
				sc.nextLine();
				String f1=sc.nextLine();
				System.out.println("Dime la segunda fecha (yyyy-mm-dd");
				String f2=sc.nextLine();
				
				Date fecha1=Date.valueOf(f1);
				Date fecha2=Date.valueOf(f2);
				
				System.out.println(ic.certi2fechas(fecha1, fecha2));
				break;
			}
			case 5:{
				
				System.out.println("Dime tu dni");
				sc.nextLine();
				String dni=sc.nextLine();
				System.out.println("Dime el codigo del certificado ");
				String cod_exame=sc.nextLine();
				ic.eliminarInscripcion(dni, cod_exame);
				break;
			}
			
			case 6:{
				System.out.println("Dime tu dni y se hara copia XML de tus certificados");
				sc.nextLine();
				String dni=sc.nextLine();
				try {
					ic.copiaXML(dni);
				} catch (SQLException | ParserConfigurationException | TransformerFactoryConfigurationError
						| TransformerException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
			default:
				break;
			}
		}
	}

}
