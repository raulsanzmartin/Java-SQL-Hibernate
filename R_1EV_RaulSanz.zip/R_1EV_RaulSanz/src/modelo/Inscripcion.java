package modelo;

public class Inscripcion {

	String dni;
	String cod_examen;
	String pagado;
	public String getDni() {
		return dni;
	}
	public void setDni(String dni) {
		this.dni = dni;
	}
	public String getCod_examen() {
		return cod_examen;
	}
	public void setCod_examen(String cod_examen) {
		this.cod_examen = cod_examen;
	}
	public String getPagado() {
		return pagado;
	}
	public void setPagado(String pagado) {
		this.pagado = pagado;
	}
	@Override
	public String toString() {
		return "Inscripcion [dni=" + dni + ", cod_examen=" + cod_examen + ", pagado=" + pagado + "]";
	}
	
	
}
