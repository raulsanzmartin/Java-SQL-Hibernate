package vista;

import java.sql.Date;
import java.sql.SQLException;
import java.util.Scanner;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;

import controladores.ControladorInscripcion;

public class Principal {

	public static void main(String[] args) throws ClassNotFoundException, SQLException, ParserConfigurationException, TransformerFactoryConfigurationError, TransformerException {
		// TODO Auto-generated method stub

		Scanner sc= new Scanner(System.in);
		ControladorInscripcion ci= new ControladorInscripcion();
		int op=0;
		while (op!=7) {
			System.out.println("1.Realizar inscripcion");
			System.out.println("2.Mostrar precio pendiente por pagar");
			System.out.println("3.Modificar a pagado certificado pendiente");
			System.out.println("4.Mostrar certificados entre 2 fechas");
			System.out.println("5.Eliminar una inscripcion");
			System.out.println("6.Copia XML");
			System.out.println("7.SALIR");
			op=sc.nextInt();
			
			switch (op) {
			case 1: {
				System.out.println("Dime tu dni");
				sc.nextLine();
				String dni=sc.nextLine();
				System.out.println("Dime que certificado quieres hacer");
				String certificado=sc.nextLine();
				
				ci.realizaInscripcion(dni, certificado);
				
				break;
			}
			case 2:{
				System.out.println("Dime tu dni");
				sc.nextLine();
				String dni=sc.nextLine();
				System.out.println("PRECIO TOTAL: "+ci.mostrarPrecioPorPagar(dni));
				break;
			}
			case 3:{
				System.out.println("Dime tu dni");
				sc.nextLine();
				String dni=sc.nextLine();
				System.out.println("Dime el codigo del certificado que quieras pagar");
				String codigo=sc.nextLine();
				ci.pagarCertificado(dni, codigo);
				break;
			}
			case 4:{
				System.out.println("Dime la primera fecha (yyyy-mm-dd)");
				sc.nextLine();
				String f1=sc.nextLine();
				System.out.println("Dime la segunda fecha (yyyy-mm-dd)");
				String f2=sc.nextLine();
				
				Date fecha1=Date.valueOf(f1);
				Date fecha2=Date.valueOf(f2);
				
				System.out.println(ci.rangoFechas(fecha1, fecha2));
				break;
				
			}
			case 5:{
				System.out.println("Dime tu dni");
				sc.nextLine();
				String dni=sc.nextLine();
				System.out.println("Dime el codigo del certificado");
				String codigo=sc.nextLine();
				ci.eliminarInscripcion(dni, codigo);
				break;
			}
			
			case 6:{
				System.out.println("Dime tu dni");
				sc.nextLine();
				String dni=sc.nextLine();
				ci.copiaXML(dni);
				break;
			}
			default:
				System.out.println("OPCION INCORRECTA");
			}
		}
	}

}
