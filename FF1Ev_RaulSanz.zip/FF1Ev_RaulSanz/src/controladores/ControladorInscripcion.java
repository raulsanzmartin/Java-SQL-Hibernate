package controladores;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

import modelo.Certificado;

public class ControladorInscripcion {

	private Connection c;
	public ControladorInscripcion() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		c=DriverManager.getConnection("jdbc:mysql://localhost/ad_recu_hibernate","root","");
	}
	
	public void realizaInscripcion(String dni, String certificado) throws SQLException {
		
		String codigo="";
		
		String sql1="Select * from certificado where descripcion=?";
		PreparedStatement ps1=c.prepareStatement(sql1);
		ps1.setString(1, certificado);
		ResultSet rs= ps1.executeQuery();
		while (rs.next()) {
			codigo=rs.getString("cod_examen");
			
		}
		
		String sql2="insert into inscripcion values(?,?,?)";
		PreparedStatement ps2=c.prepareStatement(sql2);
		ps2.setString(1, dni);
		ps2.setString(2, codigo);
		ps2.setString(3, "pendiente");
		ps2.executeUpdate();
		
		

	}
	
	public Double mostrarPrecioPorPagar(String dni) throws SQLException {
		
		Double precioTotal=0.0;
		String sql1="select * from inscripcion where dni=? and pagado=?";
		PreparedStatement ps1=c.prepareStatement(sql1);
		ps1.setString(1, dni);
		ps1.setString(2, "pendiente");
		ResultSet rs=ps1.executeQuery();
		while (rs.next()) {
			String cod_examen=rs.getString("cod_examen");
			String sql2="select * from certificado where cod_examen=?";
			PreparedStatement ps2=c.prepareStatement(sql2);
			ps2.setString(1, cod_examen);
			
			ResultSet rs2=ps2.executeQuery();
			while (rs2.next()) {
				Double precio=rs2.getDouble("precio");
				precioTotal=precioTotal+precio;
			}
		}
		return precioTotal;
		
	}
	
	public void pagarCertificado(String dni, String codigo) throws SQLException {
		String sql2="Select * from inscripcion where pagado=? and dni=? and cod_examen=?";
		PreparedStatement ps2=c.prepareStatement(sql2);
		ps2.setString(1, "pendiente");
		ps2.setString(2, dni);
		ps2.setString(3, codigo);
		ResultSet rs2=ps2.executeQuery();
		if (rs2.next()) {
			String sql="update inscripcion set pagado=? where dni=? and cod_examen=?";
			PreparedStatement ps1=c.prepareStatement(sql);
			ps1.setString(1, "pagado");
			ps1.setString(2, dni);
			ps1.setString(3, codigo);
			ps1.executeUpdate();
		}
		else {
			System.out.println("YA ESTA PAGADO");
		}
		
		
		
		
	}
	
	public List<Certificado> rangoFechas(Date fecha1,Date fecha2) throws SQLException {
		List<Certificado> l = new ArrayList<>();
		String sql="select * from certificado where fecha_examen between ? and ?";
		PreparedStatement ps1=c.prepareStatement(sql);
		ps1.setDate(1, fecha1);
		ps1.setDate(2, fecha2);
		ResultSet rs=ps1.executeQuery();
		while (rs.next()) {
			Certificado c= new Certificado();
			c.setCod_examen(rs.getString("cod_examen"));
			c.setDescripcion(rs.getString("descripcion"));
			c.setFecha_examen(rs.getDate("fecha_examen"));
			c.setPrecio(rs.getDouble("precio"));
			
			l.add(c);
		}
		return l;
		
	}
	
	public void eliminarInscripcion(String dni,String codigo) throws SQLException {
		Date hoy=Date.valueOf(LocalDate.now());
		String sql1="Select * from certificado where cod_examen=?";
		PreparedStatement ps1=c.prepareStatement(sql1);
		ps1.setString(1, codigo);
		ResultSet rs1=ps1.executeQuery();
		while (rs1.next()) {
			Date fecha_examen=rs1.getDate("fecha_examen");
			if (fecha_examen.after(hoy)) {
				
				String sql2="delete from inscripcion where dni =? and cod_examen=? and pagado=? ";
				PreparedStatement ps2=c.prepareStatement(sql2);
				ps2.setString(1, dni);
				ps2.setString(2, codigo);
				ps2.setString(3, "pendiente");
				int valor=ps2.executeUpdate();
				if (valor==1) {
					System.out.println("INSCRIPCION ELIMINADA");
				}
				else {
					System.out.println("INSCRIPCION NO ELIMINADA ");
				}
			}
			else {
				System.out.println("CERTIFICADO CADUCADO");
			}
		}
		
	}
	
	public void copiaXML(String dni) throws SQLException, ParserConfigurationException, TransformerFactoryConfigurationError, TransformerException {
		DocumentBuilderFactory dbf=DocumentBuilderFactory.newInstance();
		DocumentBuilder builder=dbf.newDocumentBuilder();
		DOMImplementation implementacion=builder.getDOMImplementation();
		Document registroCertificado=implementacion	.createDocument(null, "inscripciones", null);
		
		
		
		
		String sql1="Select * from inscripcion where dni=?";
		PreparedStatement ps1=c.prepareStatement(sql1);
		ps1.setString(1, dni);
		ResultSet rs1=ps1.executeQuery();
		while (rs1.next()) {
			String codigo=rs1.getString("cod_examen");
			String sql2="Select * from certificado where cod_examen=?";
			PreparedStatement ps2=c.prepareStatement(sql2);
			ps2.setString(1, codigo);
			ResultSet rs2= ps2.executeQuery();
			while (rs2.next()) {
				String desc=rs2.getString("descripcion");
				Date fecha=rs2.getDate("fecha_examen");
				Double precio=rs2.getDouble("precio");
				
				Element certificado=registroCertificado.createElement("certificado");
				registroCertificado.getDocumentElement().appendChild(certificado);
				
				Element cod=registroCertificado.createElement("codigo");
				Text texto=registroCertificado.createTextNode(codigo);
				cod.appendChild(texto);
				certificado.appendChild(cod);
				
				Element descripcion=registroCertificado.createElement("descripcion");
				Text texto2=registroCertificado.createTextNode(desc);
				descripcion.appendChild(texto2);
				certificado.appendChild(descripcion);
				
				Element fech=registroCertificado.createElement("fecha");
				Text texto3=registroCertificado.createTextNode(String.valueOf(fech));
				fech.appendChild(texto3);
				certificado.appendChild(fech);
				
				Element preci=registroCertificado.createElement("precio");
				Text texto4=registroCertificado.createTextNode(String.valueOf(precio));
				preci.appendChild(texto4);
				certificado.appendChild(preci);
				
				
				
				
			}
		}
		
		Source origen=new DOMSource(registroCertificado);
		Result resultado= new StreamResult(new File("src/inscripciones.xml"));
		Transformer transformador=TransformerFactory.newInstance().newTransformer();
		transformador.transform(origen, resultado);
	}
}
