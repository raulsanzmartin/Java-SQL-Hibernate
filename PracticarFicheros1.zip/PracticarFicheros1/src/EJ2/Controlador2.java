package EJ2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Controlador2 {

	
	public void escribirenFich(int op) {
		
		try {
			BufferedWriter bw= new BufferedWriter(new FileWriter("src/numeros.txt",true));
			bw.write(String.valueOf(op));
			bw.newLine();
			bw.close();
			
		} catch (IOException e) {
			// TODO: handle exception
		}
	}
	
	public Double sumarNums() {
		Double total=0.0;
		try {
			
			BufferedReader br= new BufferedReader(new FileReader("src/numeros.txt"));
			String linea="";
			while ((linea=br.readLine())!=null) {
				Double num= Double.parseDouble(linea);
				total=total+num;
			}
		} catch (IOException e) {
			// TODO: handle exception
		}
		return total;
	}
	
	public void eliminarFichero() {
		File f= new File("src/numeros.txt");
		f.delete();
	}
}

