package EJ2;

import java.util.Scanner;

public class Principal2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc= new Scanner(System.in);
		Controlador2 c = new Controlador2();
		
		int op=1;
		while (op!=0) {
			System.out.println("Dime un numero");
			op=sc.nextInt();
			c.escribirenFich(op);
		}
		System.out.println("TOTAL: "+c.sumarNums());
		c.eliminarFichero();
	}

}
