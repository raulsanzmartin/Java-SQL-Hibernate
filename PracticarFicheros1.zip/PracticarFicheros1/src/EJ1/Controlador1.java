package EJ1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Date;

public class Controlador1 {

	public void escribirFichero(String dni,String nombre,String apellidos,Date f,int num) {
		try {
			BufferedWriter br= new BufferedWriter(new FileWriter("src/datos.txt"));
			br.write(dni);
			br.newLine();
			br.write(nombre);
			br.newLine();
			br.write(apellidos);
			br.newLine();
			br.write(String.valueOf(f));
			br.newLine();
			br.write(String.valueOf(num));
			
			
			br.close();
		} catch (IOException e) {
			// TODO: handle exception
		}
		
	}
	
	public void leerFichero() {
		try {
			BufferedReader br= new BufferedReader(new FileReader("src/datos.txt"));
			String linea="";
			while ((linea=br.readLine())!=null) {
				System.out.println(linea);
			}
		} catch (IOException e) {
			// TODO: handle exception
		}
	}
}
