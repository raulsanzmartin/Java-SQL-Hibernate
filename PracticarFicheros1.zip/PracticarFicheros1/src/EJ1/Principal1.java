package EJ1;

import java.sql.Date;
import java.util.Scanner;

public class Principal1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Controlador1 c= new Controlador1();
		Scanner sc =new Scanner(System.in);
		
		System.out.println("Dime tu dni");
		String dni=sc.nextLine();
		System.out.println("Dime tu nombre");
		String nombre=sc.nextLine();
		System.out.println("Dime tus apellidos");
		String apellidos=sc.nextLine();
		System.out.println("Dime tu fecha de nacimiento (yyyy-mm-dd)");
		String f=sc.nextLine();
		System.out.println("Dime tu numero de telefono");
		int num=sc.nextInt();
		
		Date fe= Date.valueOf(f);
		c.escribirFichero(dni, nombre, apellidos, fe, num);
		
		c.leerFichero();
		
	}

}
