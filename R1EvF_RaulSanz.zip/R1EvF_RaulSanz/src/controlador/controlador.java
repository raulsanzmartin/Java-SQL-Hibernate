package controlador;

import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

import modelo.Certificado;



public class controlador {
	
	private Connection c;
	public controlador() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		c=DriverManager.getConnection("jdbc:mysql://localhost/ad_recu_hibernate","root","");
	}
	
	public void insertarInscripcion(String dni,String codigo) throws SQLException {
		
		String cod="";
		
		String sql1="Select * from Certificado where descripcion=?";
		PreparedStatement ps1=c.prepareStatement(sql1);
		ps1.setString(1, codigo);
		ResultSet rs1=ps1.executeQuery();
		
		if (rs1.next()) {
			cod=rs1.getString("cod_examen");
			String sql2="insert into inscripcion values(?,?,?)";
			PreparedStatement ps2=c.prepareStatement(sql2);
			ps2.setString(1, dni);
			ps2.setString(2, cod);
			ps2.setString(3, "pendiente");
			ps2.executeUpdate();
		}
		else {
			System.out.println("NO EXISTE ESE CERTIFICADO");
		}
		
		
	}
	public Double mostrarPrecioPendiente(String dni) throws SQLException {
		
		Double precioTotal=0.0;
		
		String sql1="Select * from inscripcion where dni=? and pagado=?";
		PreparedStatement ps1=c.prepareStatement(sql1);
		ps1.setString(1, dni);
		ps1.setString(2, "pendiente");
		ResultSet rs1=ps1.executeQuery();
		while (rs1.next()) {
			String codigo=rs1.getString("cod_examen");
			String sql2="Select * from certificado where cod_examen=?";
			PreparedStatement ps2=c.prepareStatement(sql2);
			ps2.setString(1, codigo);
			ResultSet rs2=ps2.executeQuery();
			while (rs2.next()) {
				Double precio=rs2.getDouble("precio");
				precioTotal=precioTotal+precio;
			}
		}
		return precioTotal;
	}
	
	public void cambiarAPagado(String dni,String certificado) throws SQLException {
		String sql1="Select * from certificado where descripcion=?";
		PreparedStatement ps1=c.prepareStatement(sql1);
		ps1.setString(1, certificado);
		ResultSet rs1=ps1.executeQuery();
		if (rs1.next()) {
			String codigo=rs1.getString("cod_examen");
		
			String sql2="Update inscripcion set pagado=? where dni=? and cod_examen=?";
			PreparedStatement ps2=c.prepareStatement(sql2);
			ps2.setString(1, "pagado");
			ps2.setString(2, dni);
			ps2.setString(3, codigo);
			ps2.executeUpdate();	
			
		}
		else {
			System.out.println("CERTIFICADO NO ENCONTRADO");
		}
	}
	
	public List<Certificado> mostrarEnRango(String fecha1,String fecha2) throws SQLException {
		List<Certificado> l =new ArrayList<>();
		
		Date fecha1bien=Date.valueOf(fecha1);
		Date fecha2bien=Date.valueOf(fecha2);
		
		String sql1="Select * from certificado where fecha_examen between ? and ?";
		PreparedStatement ps1=c.prepareStatement(sql1);
		ps1.setDate(1, fecha1bien);
		ps1.setDate(2, fecha2bien);
		ResultSet rs1=ps1.executeQuery();
		
		while (rs1.next()) {
			Certificado c= new Certificado();
			String codigo=rs1.getString("cod_examen");
			String descripcion=rs1.getString("descripcion");
			Date fecha=rs1.getDate("fecha_examen");
			Double precio=rs1.getDouble("precio");
			c.setCod_examen(codigo);
			c.setDescripcion(descripcion);
			c.setFecha_examen(fecha);
			c.setPrecio(precio);
			l.add(c);
			
			
		}
		return l;
	}
	public void eliminarInscripcion(String dni,String certificado) throws SQLException {
		Date hoy=Date.valueOf(LocalDate.now());
		String sql1="Select * from certificado where descripcion=?";
		PreparedStatement ps1=c.prepareStatement(sql1);
		ps1.setString(1,certificado);
		ResultSet rs1=ps1.executeQuery();
		if (rs1.next()) {
			
			String codigo=rs1.getString("cod_examen");
			Date fechaExamen=rs1.getDate("fecha_examen");
			if (fechaExamen.after(hoy)) {
				String sql2="Select * from inscripcion where cod_examen=? and pagado=?";
				PreparedStatement ps2=c.prepareStatement(sql2);
				ps2.setString(1, codigo);
				ps2.setString(2, "pendiente");
				
				ResultSet rs2=ps2.executeQuery();
				if (rs2.next()) {
					String sql3="Delete from inscripcion where dni=? and cod_examen=? ";
					PreparedStatement ps3=c.prepareStatement(sql3);
					ps3.setString(1, dni);
					ps3.setString(2,codigo);
					ps3.executeUpdate();
				}	
				else {
					System.out.println("CERTIFICADO PAGADO, NO SE PUEDE ELIMINAR");
				}
			}else {
				System.out.println("CERTIFICADO CADUCADO,NO SE PUEDE ELIMINAR");
			}
			
		}
	}
	public void copiaXML(String dni) throws SQLException, ParserConfigurationException, TransformerFactoryConfigurationError, TransformerException {
		System.out.println(dni);
		String sql1="Select * from inscripcion where dni=?";
		PreparedStatement ps1=c.prepareStatement(sql1);
		ps1.setString(1, dni);
		ResultSet rs1=ps1.executeQuery();
		
		DocumentBuilderFactory dbf= DocumentBuilderFactory.newInstance();
		DocumentBuilder builder=dbf.newDocumentBuilder();
		DOMImplementation implementacion=builder.getDOMImplementation();
		Document registroCertificados=implementacion.createDocument(null, "inscripcion", null);
		
		
		while (rs1.next()) {
			
			String codigo=rs1.getString("cod_examen");
			System.out.println(codigo);
			String sql2="Select * from certificado where cod_examen=?";
			PreparedStatement ps2=c.prepareStatement(sql2);
			ps2.setString(1, codigo);
			ResultSet rs2=ps2.executeQuery();
			while (rs2.next()) {
				
				String desc=rs2.getString("descripcion");
				Date fecha=rs2.getDate("fecha_examen");
				Double precio=rs2.getDouble("precio");
				System.out.println(desc+fecha+precio);
				
				Element certificado=registroCertificados.createElement("certificado");
				registroCertificados.getDocumentElement().appendChild(certificado);
				
				Element cod=registroCertificados.createElement("cod_examen");
				Text textoCod=registroCertificados.createTextNode(codigo);
				cod.appendChild(textoCod);
				certificado.appendChild(cod);
				
				Element fechabien=registroCertificados.createElement("fecha_examen");
				Text textoFech=registroCertificados.createTextNode(fecha.toString());
				fechabien.appendChild(textoFech);
				certificado.appendChild(fechabien);
				
				Element precioBien=registroCertificados.createElement("precio");
				Text textoPre=registroCertificados.createTextNode(precio.toString());
				precioBien.appendChild(textoPre);
				certificado.appendChild(precioBien);
				
				
				
				
			}
			Source origen=new DOMSource(registroCertificados);
			Result resultado=new StreamResult(new File("src/certificados.xml"));
			Transformer transformador=TransformerFactory.newInstance().newTransformer();
			transformador.transform(origen, resultado);
		}
		
		
				
	}
	
	
}
