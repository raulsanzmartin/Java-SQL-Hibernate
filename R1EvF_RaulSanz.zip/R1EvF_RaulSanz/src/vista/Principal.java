package vista;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;

import controlador.controlador;

public class Principal {

	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
		// TODO Auto-generated method stub
		
		controlador c= new controlador();
		
		Scanner sc=new Scanner(System.in);
		int op=0;
		
		while (op!=7) {
			System.out.println("1.Realizar una inscripcion a un certificado");
			System.out.println("2.Mostrar precio pendiente por pagar");
			System.out.println("3.Modificar a pagado un certificado pendiente de pago");
			System.out.println("4.Mostrar certificados en un rango de fechas");
			System.out.println("5.Eliminar inscripcion");
			System.out.println("6.Copia a XML");
			System.out.println("7.SALIR");
			op=sc.nextInt();
			switch (op) {
			case 1: {
				System.out.println("Dime tu dni");
				sc.nextLine();
				String dni=sc.nextLine();
				System.out.println("Dime el certificado que quieres hacer");
				String certificado=sc.nextLine();
				c.insertarInscripcion(dni, certificado);
				break;
			}
			case 2:{
				System.out.println("Dime tu dni");
				sc.nextLine();
				String dni=sc.nextLine();
				System.out.println("PRECIO PENDIENTE TOTAL: "+c.mostrarPrecioPendiente(dni));
				break;
			}
			case 3:{
				System.out.println("Dime tu dni");
				sc.nextLine();
				String dni=sc.nextLine();
				System.out.println("Que certificado quieres pagar");
				String certificado=sc.nextLine();
				c.cambiarAPagado(dni, certificado);
				break;
			}
			case 4:{
				System.out.println("Dime la primera fecha(yyyy-mm-dd)");
				sc.nextLine();
				String fecha1=sc.nextLine();
				System.out.println("Dime la segunda fehca(yyyy-mm-dd)");
				String fecha2=sc.nextLine();
				System.out.println(c.mostrarEnRango(fecha1, fecha2));
				break;
				
			}
			case 5:{
				System.out.println("Dime tu dni");
				sc.nextLine();
				String dni=sc.nextLine();
				System.out.println("dime el certificado que quieres eliminar la inscripcion");
				String certificado=sc.nextLine();
				c.eliminarInscripcion(dni, certificado);
				break;
			}
			case 6:{
				System.out.println("Dime tu dni y se hara copia XML de tus inscripciones");
				String dni=sc.nextLine();
				sc.nextLine();
				try {
					c.copiaXML(dni);
				} catch (SQLException | ParserConfigurationException | TransformerFactoryConfigurationError
						| TransformerException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}
			
			default:
				System.out.println("OPCION INCORRECTA");
			}
			
		}
	}

}
